---
name: Dynamic Commerce System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#5b4137'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#8f7065'
  outline-variant: '#e4beb1'
  surface-tint: '#a73a00'
  primary: '#a73a00'
  on-primary: '#ffffff'
  primary-container: '#ff5c00'
  on-primary-container: '#521800'
  inverse-primary: '#ffb59a'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#005ac2'
  on-tertiary: '#ffffff'
  tertiary-container: '#5190ff'
  on-tertiary-container: '#002960'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#802a00'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 20px
  gutter: 16px
  touch-target: 48px
---

## Brand & Style

The design system is engineered for high-velocity mobile commerce. It communicates energy, reliability, and immediate action through a "Modern-Vibrant" aesthetic. By combining the cleanliness of high-end SaaS with the urgency of retail, the system creates an environment where products are the hero, and the interface serves as a frictionless conduit to purchase.

The visual language balances heavy whitespace with punchy, high-saturation accents. It avoids visual clutter, favoring clear paths to conversion and generous interactive zones. The goal is to evoke a feeling of "Instant Gratification"—where the UI feels as fast and responsive as the brand's delivery promise.

## Colors

This design system utilizes a high-contrast palette to drive user attention toward conversion points.

- **Primary (Vibrant Orange):** Used exclusively for call-to-action buttons, active states, and promotional highlights. This color is the "engine" of the interface.
- **Secondary (Deep Navy):** Provides a grounding contrast for primary headers and navigation elements, ensuring text remains legible and authoritative.
- **Tertiary (Electric Blue):** Reserved for informational cues, badges, and secondary interactive elements like "View Details" links.
- **Neutral:** A clean, cool-gray scale (Slate) is used for backgrounds and borders to keep the interface feeling airy and modern.

The background is strictly white (#FFFFFF) to ensure product photography is rendered with maximum color accuracy.

## Typography

The typography system relies on **Inter** for its exceptional legibility and systematic weights. To support the "energetic" brand personality, we use a clear hierarchy:

- **Promotional Boldness:** Use `display-lg` and `headline-lg` for flash sales and hero sections. Tight letter-spacing on these levels creates a dense, professional "editorial" look.
- **Functional Clarity:** Body text uses standard weights with generous line-height to prevent eye fatigue during long browsing sessions.
- **Utility Labels:** `label-lg` is frequently used for price tags and category chips, utilizing a semi-bold weight to stand out against white backgrounds.

## Layout & Spacing

This design system employs a **Fluid Grid** model optimized for the viewport of modern smartphones.

- **The 8px Rhythm:** All spacing (padding, margins, and gaps) is a multiple of 4px, with 8px being the core unit of separation between related elements.
- **Mobile Grid:** A 4-column grid with a `20px` side margin and a `16px` gutter. Product cards typically span 2 columns in a "grid view" or 4 columns in a "list view."
- **Touch Targets:** A strict minimum of `48px` for all interactive elements (buttons, icons, toggles) to ensure accessibility and ease of use while moving.
- **Safe Zones:** Generous bottom padding is applied to all scrollable views to prevent interference with mobile OS navigation bars.

## Elevation & Depth

To maintain the "Modern-Vibrant" style without veering into skeuomorphism, the design system uses **Ambient Shadows** and **Tonal Layering**.

- **Level 0 (Base):** The main background (#FFFFFF).
- **Level 1 (Cards):** Subsurface elevation. Uses a 1px border (#E2E8F0) and a soft, low-opacity shadow (Y: 4px, Blur: 12px, Alpha: 0.05).
- **Level 2 (Active/Floating):** Used for "Add to Cart" bars and floating action buttons. Uses a more pronounced shadow (Y: 8px, Blur: 20px, Alpha: 0.1) to suggest these elements sit above the content.
- **Scrims:** When modals or "Quick View" panels are active, a 40% opacity navy (#0F172A) scrim is used to focus user attention.

## Shapes

The shape language is defined by a friendly but structured **Rounded** (Value 2) profile.

- **Standard Elements:** Buttons, input fields, and small badges use a **0.5rem (8px)** corner radius.
- **Container Elements:** Product cards and larger content sections use a **1rem (16px)** corner radius to create a soft, approachable frame for imagery.
- **Full Rounding:** Search bars and "Status" chips (e.g., "In Stock") use a pill-shape (full rounding) to differentiate them from actionable buttons.

## Components

- **Buttons:** Primary buttons use a solid Vibrant Orange background with white text. They include a subtle "press" state where the button scales down to 98% and the shadow deepens.
- **Product Cards:** Featuring a white background, 16px corner radius, and a subtle bottom shadow. The product image must always occupy the top 60% of the card area.
- **Chips:** Used for sizing, categories, or filters. They feature a light-gray background (#F1F5F9) that transitions to the primary color when selected.
- **Input Fields:** 48px height minimum. They use a 1px border (#CBD5E1). On focus, the border color shifts to Primary Orange with a 2px outer glow.
- **Checkboxes & Radios:** Scaled to 24px for easy tapping. When checked, they use a solid Primary Orange fill with white checkmarks/dots.
- **Bottom Sheets:** For mobile filters and product options, these slide up from the bottom with a 24px top-corner radius and a prominent handle for swiping.