---
name: Azure Modernist
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#424656'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#727687'
  outline-variant: '#c2c6d8'
  surface-tint: '#0054d6'
  primary: '#0050cb'
  on-primary: '#ffffff'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#b3c5ff'
  secondary: '#585f66'
  on-secondary: '#ffffff'
  secondary-container: '#dce3eb'
  on-secondary-container: '#5e656c'
  tertiary: '#00636f'
  on-tertiary: '#ffffff'
  tertiary-container: '#007e8d'
  on-tertiary-container: '#ebfbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#dce3eb'
  secondary-fixed-dim: '#c0c7cf'
  on-secondary-fixed: '#151c22'
  on-secondary-fixed-variant: '#40484e'
  tertiary-fixed: '#9cf0ff'
  tertiary-fixed-dim: '#00daf3'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f58'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The brand personality is energetic, reliable, and forward-thinking. It targets a modern consumer base that values speed, clarity, and a premium shopping experience. The UI evokes a sense of freshness and technological sophistication.

The design style is **Corporate / Modern** with a lean towards **Minimalism**. It utilizes expansive white space, a disciplined color application, and high-quality typography to ensure the product remains the hero. The aesthetic is clean and high-fidelity, avoiding unnecessary ornamentation in favor of functional elegance and precise execution.

## Colors

The palette is centered around a vibrant, fresh primary blue that signifies trust and innovation. 

- **Primary (#0066FF):** Used for key call-to-actions, active states, and brand signifiers. It is high-chroma to ensure it pops against neutral backgrounds.
- **Secondary (#F0F7FF):** A very light blue tint used for large surface areas, subtle containers, and hover states to provide a soft alternative to pure white.
- **Tertiary (#00E5FF):** A bright cyan used sparingly for highlights, success indicators, or decorative accents that require a secondary level of attention.
- **Neutral (#1A1C1E):** A deep, near-black charcoal used for primary text and structural elements to maintain high legibility and a grounded feel.

Surface colors follow a tonal scale:
- **Surface:** #FFFFFF (Pure white for maximum clarity)
- **Surface-Container:** #F8FAFC (Low-contrast grey-blue for grouping content)
- **Surface-Variant:** #E2E8F0 (Borders and disabled states)

## Typography

This design system utilizes a dual-font strategy to balance character with utility. **Plus Jakarta Sans** is used for headlines to provide a friendly, modern, and slightly rounded geometric feel that softens the corporate edge. **Inter** is used for body copy and labels due to its exceptional legibility and systematic, neutral nature.

Headlines should use tighter letter spacing as they scale up to maintain visual tension. Body text prioritizes vertical rhythm, using a generous line height to enhance readability in long-form descriptions or product specifications.

## Layout & Spacing

The layout is based on a **12-column fluid grid** for desktop and a **4-column fluid grid** for mobile. A strict 4px soft-grid scale governs all spatial relationships.

- **Desktop:** 12 columns, 24px gutters, 64px side margins.
- **Tablet:** 8 columns, 24px gutters, 32px side margins.
- **Mobile:** 4 columns, 16px gutters, 16px side margins.

Vertical spacing should leverage the `xxl` (48px) unit between major sections to emphasize the minimalist, airy aesthetic. Component-level spacing (internal padding) should primarily use `md` (16px) for a balanced, breathable feel.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. Instead of heavy shadows, the system uses subtle color shifts in surface containers to define depth.

- **Level 0 (Floor):** White (#FFFFFF).
- **Level 1 (Cards/Containers):** Secondary Blue (#F0F7FF) or White with a 1px border (#E2E8F0).
- **Level 2 (Overlays/Modals):** White with a soft, diffused shadow. Shadows are tinted with the Primary Blue: `box-shadow: 0 10px 30px rgba(0, 102, 255, 0.08)`.

Transitions between layers are always crisp, relying more on subtle shifts in background saturation than on dark shadows.

## Shapes

The shape language is consistently **Rounded**. This mirrors the friendly geometry of the headline typeface and provides a modern, approachable feel to the commerce experience.

- **Small Components (Buttons, Inputs, Chips):** 0.5rem (8px).
- **Medium Components (Cards, Modals):** 1rem (16px).
- **Large Components (Sections, Hero Banners):** 1.5rem (24px).

Interactive elements should maintain these radii strictly to ensure the UI feels cohesive and intentional.

## Components

- **Buttons:** Primary buttons use the #0066FF background with white text. Ghost buttons use a 1px border of #0066FF and primary blue text. All buttons have 0.5rem roundedness and use `label-lg` typography.
- **Chips:** Used for categories and filters. They feature the Secondary Blue (#F0F7FF) background with Primary Blue (#0066FF) text.
- **Input Fields:** 1px border (#E2E8F0) that transitions to Primary Blue (#0066FF) on focus. Labels use `label-md` placed above the field.
- **Cards:** Product cards use a white background, 1rem roundedness, and a subtle border. On hover, apply the Level 2 ambient shadow.
- **Lists:** Clean, border-bottom separated items (#F8FAFC) with generous `md` padding.
- **Checkboxes/Radios:** When active, they are filled with Primary Blue. The check/bullet is always white.
- **Navigation:** Top-tier navigation uses `label-lg` with a high-contrast Primary Blue indicator bar (2px) for active states.