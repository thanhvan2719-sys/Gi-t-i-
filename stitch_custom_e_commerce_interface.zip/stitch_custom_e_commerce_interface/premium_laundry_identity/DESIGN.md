---
name: Premium Laundry Identity
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#3f4a3c'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#6f7a6b'
  outline-variant: '#becab9'
  surface-tint: '#006e1c'
  primary: '#006e1c'
  on-primary: '#ffffff'
  primary-container: '#4caf50'
  on-primary-container: '#003c0b'
  inverse-primary: '#78dc77'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#9a9b9b'
  on-tertiary-container: '#313333'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#94f990'
  primary-fixed-dim: '#78dc77'
  on-primary-fixed: '#002204'
  on-primary-fixed-variant: '#005313'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  button:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is built on the pillars of transparency, efficiency, and clinical precision. It targets high-end urban professionals who value their time and the longevity of their garments. 

The aesthetic is **Minimalist and Modern**, drawing inspiration from contemporary high-end lifestyle services. It utilizes heavy whitespace to evoke a sense of cleanliness and "breathing room," mirroring the freshness of laundered linens. The visual language is intentional and quiet, ensuring that the user feels a sense of calm and trust throughout the service booking process.

## Colors
The palette is rooted in a crisp, high-contrast foundation to emphasize hygiene and clarity.

- **Primary Green (#4CAF50):** Represents freshness, eco-friendly practices, and the "Go" signal for service efficiency. It is used sparingly for primary actions and status indicators.
- **Deep Onyx (#1A1A1A):** Used for primary typography and iconography to ensure maximum legibility and a premium, grounded feel.
- **Pristine White (#FFFFFF):** The dominant background color to maintain a clinical, spotless environment.
- **Soft Greys (#F5F5F5, #EEEEEE):** Used for surface differentiation, subtle dividers, and secondary containers to avoid the harshness of pure black-on-white borders.

## Typography
This design system employs **Inter** for its systematic, utilitarian, and modern characteristics. The type scale is optimized for high readability in task-oriented interfaces.

- **Headlines:** Set with tighter letter spacing and heavier weights to create a strong visual anchor.
- **Body Text:** Utilizes generous line heights to ensure a relaxed reading experience.
- **Labels:** Small caps are used for category tags and metadata to provide a distinct visual hierarchy without competing with body text.

## Layout & Spacing
The layout follows a **Fluid Grid** model based on an 8px square baseline. 

- **Desktop:** A 12-column grid with 24px gutters. Content is centered within a 1200px max-width container.
- **Mobile:** A 4-column grid with 16px margins.
- **Spacing Logic:** Use 8px increments for internal component spacing (padding/gap) and 16px/24px/32px for layout-level separation. Large sections should be separated by 64px or 80px to maintain the minimalist "airy" feel.

## Elevation & Depth
Elevation is expressed through **Tonal Layers** and **Ambient Shadows** rather than heavy borders.

- **Level 0 (Background):** Pure #FFFFFF.
- **Level 1 (Cards/Containers):** Subtle off-white or #F9F9F9 with a 1px border in #EEEEEE.
- **Level 2 (Active/Floating):** An ultra-diffused shadow: `0px 4px 20px rgba(0, 0, 0, 0.04)`.
- **Interactions:** On hover, cards should slightly lift using a more pronounced shadow: `0px 12px 30px rgba(0, 0, 0, 0.08)` and a subtle Y-axis translation (-2px).

## Shapes
The shape language is consistently **Rounded**, reflecting the soft nature of fabric and the approachable quality of the service. 

- **Standard Radius:** 8px (0.5rem) for buttons and input fields.
- **Large Radius:** 16px (1rem) for service cards and modal containers.
- **Extra Large Radius:** 24px (1.5rem) for promotional banners or feature sections.

## Components
Consistent application of components ensures a professional, high-trust user experience.

- **Buttons:** Primary buttons use a solid Primary Green background with White text. Secondary buttons use a transparent background with a 1px Grey border. Transitions should be a smooth 200ms ease-in-out.
- **Cards:** Used for service selection (e.g., "Wash & Fold," "Dry Clean"). Cards should feature ample padding (24px) and clear, thin-stroke iconography.
- **Input Fields:** Minimalist style with a 1px border that turns Primary Green on focus. Use "Inter" at 16px for input text to prevent iOS zoom-on-focus issues.
- **Chips/Tags:** Used for "Order Status" (e.g., "Cleaning," "Ready for Delivery"). Use low-saturation background tints of the status color with high-saturation text.
- **Icons:** Use linear, 2px stroke icons to match the systematic feel of the typography. Avoid filled icons unless indicating an active toggle state.
- **Progress Indicators:** Use a thin 4px horizontal bar for multi-step booking processes to maintain a non-intrusive UI.